#!/usr/bin/python3
# coding = utf-8


# data.loader content :
#   variables :
# icodico, all_icons_list, normal_icons_list, standard_icons_list, symbolic_icons_list, stock_ids_list
# functions :
# test_load, timetest(str)


import pickle
import time
from data.toolbox import *

# ================================VARIABLES==============================|

chronoproc("loading datas")

# icodico
with open("data/ico.dict", "rb") as file:
    my_unpickler = pickle.Unpickler(file)
    icodico = my_unpickler.load()

# all_icons_list
with open("data/icons_all.list", "rb") as file:
    my_unpickler = pickle.Unpickler(file)
    both_icons_list = my_unpickler.load()

# normal_icons_list
with open("data/icons_normal.list", "rb") as file:
    my_unpickler = pickle.Unpickler(file)
    normal_icons_list = my_unpickler.load()

# standard_icons_list
with open("data/icons_standard.list", "rb") as file:
    my_unpickler = pickle.Unpickler(file)
    standard_icons_list = my_unpickler.load()

# symbolic_icons_list
with open("data/icons_symbolic.list", "rb") as file:
    my_unpickler = pickle.Unpickler(file)
    symbolic_icons_list = my_unpickler.load()

# stock_ids_list
with open("data/stock_ids.list", "rb") as file:
    my_unpickler = pickle.Unpickler(file)
    stock_ids_list = my_unpickler.load()
    len_stock_list = len(stock_ids_list)-1
    del stock_ids_list[len_stock_list]

chronoproc("datas loaded")


# ======================FUNCTIONS & MINOR CLASS==================================================|

def test_load():
    print(icodico.keys())
    print(both_icons_list)
    print(normal_icons_list)
    print(standard_icons_list)
    print(symbolic_icons_list)
    print(stock_ids_list)
