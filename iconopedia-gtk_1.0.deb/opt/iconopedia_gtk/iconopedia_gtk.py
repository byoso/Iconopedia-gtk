#!/usr/bin/python3
# coding = utf-8

# Copyright 2017 Fabre Vincent (peigne-plume@laposte.net)
#
# Redistribution and use in source and binary forms, with or without modification, are
# permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this list of
# conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of
#  conditions and the following disclaimer in the documentation and/or other materials
# provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
# OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from data.loader import *
from data.toolbox import *
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GdkPixbuf

# data.loader content :
#   variables :
# icodico, all_icons_list, normal_icons_list, standard_icons_list, symbolic_icons_list, stock_ids_list
# data.toolbox content :
#   chronoproc(str,str) - the str arguments are optional
#   license_BSD (str variable)

test_label = Gtk.Label("test label")
test_load()


class MyRow(Gtk.ListBoxRow):

    def __init__(self, icon_name):
        Gtk.ListBoxRow.__init__(self)
        self.set_properties(activatable=True, selectable=True)
        self.icon_name = icon_name
        self.connect("focus-in-event", self.display_description)

    def display_description(self, widget, EventFocus):
        if self.icon_name in MainWindow.icodico:
            window.label_icon_desc.set_markup(MainWindow.icodico[self.icon_name])
        else:
            window.label_icon_desc.set_markup("No description available.")
            # anyway display the sample icons :
        window.show_icon1.set_from_icon_name(self.icon_name, 1)
        window.show_icon2.set_from_icon_name(self.icon_name, 2)
        window.show_icon3.set_from_icon_name(self.icon_name, 3)
        window.show_icon4.set_from_icon_name(self.icon_name, 4)
        window.show_icon5.set_from_icon_name(self.icon_name, 5)
        window.show_icon6.set_from_icon_name(self.icon_name, 6)

        code_example = "\nmy_button = Gtk.Button()\nmy_image = Gtk.Image.new_from_icon_name(\"" + str(\
            self.icon_name) + "\", Gtk.IconSize(5))\nmy_button.add(my_image)\n"
        window.label_code_sample.set_markup(code_example)


class MySIRow(Gtk.ListBoxRow):

    def __init__(self, stock_id):
        Gtk.ListBoxRow.__init__(self)
        self.stock_row_layer = Gtk.HBox()
        self.add(self.stock_row_layer)
        self.stock_id = stock_id
        self.stock_row_button = Gtk.Button()
        textorun1 = "self.stock_row_button = Gtk.Button.new_from_stock({})".format(self.stock_id)
        exec(textorun1)
        self.stock_row_button.set_always_show_image(True)
        self.stock_row_layer.pack_start(self.stock_row_button, False, False, 0)
        textorun2 = "self.stock_row_label = Gtk.Label({})".format(self.stock_id)
        exec(textorun2)
        self.stock_row_label.set_selectable(True)
        self.stock_row_layer.pack_end(self.stock_row_label, False, False, 5)
        self.stock_icon_name = "Icon name : "+self.stock_row_label.get_label()
        self.connect("focus-in-event", self.display_stock_samples)

    def display_stock_samples(self, widget, EventFocus):
        stock_id_name = "Stock ID : "+self.stock_id
        window.si_title_label.set_markup(stock_id_name)
        window.si_icon_name.set_markup(self.stock_icon_name)

        # displays the sample
        text1 = "\nmy_button = Gtk.Button.new_from_stock({})".format(self.stock_id)
        text2 = "\nmy_button.set_always_show_image(True)"
        sample = text1+text2
        window.si_label2.set_markup(sample)


class MainWindow(Gtk.Window):

    icodico = icodico

    def __init__(self):

        Gtk.Window.__init__(self)
        self.set_size_request(800, 600)
        self.set_border_width(10)
        self.set_default_icon_from_file("data/iconopedia.png")

        # headerbar
        header_bar = Gtk.HeaderBar()
        header_bar.set_show_close_button(True)
        header_bar.set_title("Iconopedia GTK+")
        header_bar.set_subtitle("A handy tool for PyGobject devs !")
        info_button = Gtk.Button()
        info_image = Gtk.Image.new_from_icon_name("help-about", Gtk.IconSize(3))
        info_button.add(info_image)
        info_button.connect("clicked", self.info_clicked)
        header_bar.pack_start(info_button)
        self.set_titlebar(header_bar)

        # stack
        stack = Gtk.Stack()
        stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        stack.set_transition_duration(500)
        self.add(stack)

        # Stck switcher
        stack_switcher = Gtk.StackSwitcher()
        stack_switcher.set_stack(stack)
        header_bar.pack_end(stack_switcher)

        #   Iconopedia main layer
        iconopedia_layer = Gtk.HBox()
        stack.add_titled(iconopedia_layer, "stack1", "Iconopedia")

        #       VBox notebook
        self.note_box = Gtk.VBox()
        self.note_box.set_homogeneous(False)
        self.note_box.set_size_request(520, 200)
        iconopedia_layer.pack_start(self.note_box, False, False, 10)

        #           Notebook
        self.notebook = Gtk.Notebook()

        # initiate the Gtk.notebooks
        self.notebooks_names = []
        self.normal_book = Gtk.Notebook()
        self.symbolic_book = Gtk.Notebook()
        self.both_book = Gtk.Notebook()
        self.standard_book = Gtk.Notebook()

        # lists from data.loader
        self.normal_list = normal_icons_list
        self.symbolic_list = symbolic_icons_list
        self.both_list = both_icons_list
        self.standard_list = standard_icons_list

        # will be set to "True" once the corresponding notebook is built
        self.test_normal = False
        self.test_symbolic = False
        self.test_both = False
        self.test_standard = False

        #       VBox infos
        info_box = Gtk.VBox()
        info_box.set_size_request(420, 300)
        label_title_icon_desc = Gtk.Label("Icon description :")
        self.label_icon_desc = Gtk.Label()
        self.label_icon_desc.set_line_wrap(True)
        self.label_icon_desc.set_selectable(True)
        info_box.pack_start(label_title_icon_desc, False, False, 0)
        info_box.pack_start(self.label_icon_desc, False, False, 0)
        iconopedia_layer.pack_start(info_box, False, False, 0)

        # 6 icons to show all different sizes
        box_for_6 = Gtk.Box()
        box_for_6.set_halign(Gtk.Align(3))
        info_box.pack_start(box_for_6, True, True, 0)

        self.show_icon1 = Gtk.Image.new_from_icon_name("content-loading-symbolic", Gtk.IconSize(1))
        self.show_icon2 = Gtk.Image.new_from_icon_name("content-loading-symbolic", Gtk.IconSize(2))
        self.show_icon3 = Gtk.Image.new_from_icon_name("content-loading-symbolic", Gtk.IconSize(3))
        self.show_icon4 = Gtk.Image.new_from_icon_name("content-loading-symbolic", Gtk.IconSize(4))
        self.show_icon5 = Gtk.Image.new_from_icon_name("content-loading-symbolic", Gtk.IconSize(5))
        self.show_icon6 = Gtk.Image.new_from_icon_name("content-loading-symbolic", Gtk.IconSize(6))
        box_for_6.pack_start(self.show_icon1, False, False, 5)
        box_for_6.pack_start(self.show_icon2, False, False, 5)
        box_for_6.pack_start(self.show_icon3, False, False, 5)
        box_for_6.pack_start(self.show_icon4, False, False, 5)
        box_for_6.pack_start(self.show_icon5, False, False, 5)
        box_for_6.pack_start(self.show_icon6, False, False, 5)
        box_for_6.pack_start(self.show_icon6, False, False, 5)

        # code sample
        label_title_code_sample = Gtk.Label("Python3 code sample  (size must be an int from 1 to 6) :")
        info_box.pack_start(label_title_code_sample, False, False, 0)
        self.label_code_sample = Gtk.Label()
        self.label_code_sample.set_line_wrap(True)
        self.label_code_sample.set_selectable(True)
        info_box.pack_start(self.label_code_sample, False, False, 10)
        #           radio box
        radio_box = Gtk.VBox()
        info_box.pack_start(radio_box, False, False, 0)
        #       radiobuttons in a link box
        #       create a box of linked items
        link_box = Gtk.HBox()
        Gtk.StyleContext.add_class(link_box.get_style_context(), "linked")

        self.normal_radio = Gtk.RadioButton.new_with_label_from_widget(None, "Normal")
        self.symbolic_radio = Gtk.RadioButton.new_with_label_from_widget(self.normal_radio, "Symbolic")
        self.both_radio = Gtk.RadioButton.new_with_label_from_widget(self.normal_radio, "Both")
        self.standard_radio = Gtk.RadioButton.new_with_label_from_widget(self.normal_radio, "Standard")

        self.note_box.pack_start(link_box, False, False, 0)
        link_box.add(self.normal_radio)
        link_box.add(self.symbolic_radio)
        link_box.add(self.both_radio)
        link_box.add(self.standard_radio)

        self.normal_radio.connect("toggled", self.radio, "normal")
        self.symbolic_radio.connect("toggled", self.radio, "symbolic")
        self.both_radio.connect("toggled", self.radio, "both")
        self.standard_radio.connect("toggled", self.radio, "standard")
        self.standard_radio.set_active(True)

        # ============================== Stock Items layer =================================
        stock_layer = Gtk.HBox()
        stack.add_titled(stock_layer, "stack2", "Stock items")
        #       VBox notebook
        sil_box_l = Gtk.VBox()
        sil_box_l.set_size_request(500, 200)
        stock_layer.add(sil_box_l)
        #           Stock items Listbox
        stock_items_scroll = Gtk.ScrolledWindow()
        sil_box_l.add(stock_items_scroll)
        self.stock_items_listbox = Gtk.ListBox()
        stock_items_scroll.add(self.stock_items_listbox)

        for stock_id in stock_ids_list:
            row = MySIRow(stock_id)
            self.stock_items_listbox.add(row)
            # color alternance:
            if row.get_index() % 2 == 0:
                row.stock_row_layer.override_background_color(Gtk.StateType.NORMAL, Gdk.RGBA(.3, .1, .4, .5))

        #       VBox infos
        self.sil_box_r = Gtk.VBox()
        self.sil_box_r.set_homogeneous(False)
        self.sil_box_r.set_size_request(400, 300)
        stock_layer.add(self.sil_box_r)
        self.si_title_label = Gtk.Label("Samples and examples")
        self.si_title_label.set_selectable(True)
        self.sil_box_r.pack_start(self.si_title_label, False, False, 5)
        self.si_icon_name = Gtk.Label()
        self.si_icon_name.set_selectable(True)
        self.sil_box_r.pack_start(self.si_icon_name, False, False, 5)

        # a separator
        separator = Gtk.Separator.new(Gtk.Orientation.HORIZONTAL)
        self.sil_box_r.pack_start(separator, False, False, 0)

        # Button from stock item Sample

        self.si_label1 = Gtk.Label("\nPython3 code sample to create a button :")
        self.sil_box_r.pack_start(self.si_label1, False, False, 0)
        self.si_label2 = Gtk.Label()
        self.si_label2.set_selectable(True)
        self.si_label2.set_line_wrap(True)
        self.sil_box_r.pack_start(self.si_label2, False, False, 0)

        # a simple wedge (i know it is ugly...)
        self.wedge = Gtk.Label("""                                                  
                                                                                        
                                                                                       
                                                                                                          
                                                                                         """)

        self.sil_box_r.pack_start(self.wedge, False, False, 0)

    def radio(self, widget, name):

        chronoproc("Radio touched", "\n# ")

        if widget.get_active():
            state = "on"
            print("{} is set {}".format(name, state))
        else:
            state = "off"
            print("{} is set {}".format(name, state))
        chronoproc("Radio toggled")

        if self.normal_radio.get_active():
            self.normal_book.hide()
            self.symbolic_book.hide()
            self.both_book.hide()
            self.standard_book.hide()
            if self.test_normal:
                self.normal_book.show()
            else:
                self.normal_book = self.notebook_builder("normal")
                self.note_box.add(self.normal_book)
                self.normal_book.show_all()

        if self.symbolic_radio.get_active():
            self.normal_book.hide()
            self.symbolic_book.hide()
            self.both_book.hide()
            self.standard_book.hide()
            if self.test_symbolic:
                self.symbolic_book.show()
            else:
                self.symbolic_book = self.notebook_builder("symbolic")
                self.note_box.add(self.symbolic_book)
                self.symbolic_book.show_all()

        if self.both_radio.get_active():
            self.normal_book.hide()
            self.symbolic_book.hide()
            self.both_book.hide()
            self.standard_book.hide()
            if self.test_both :
                self.both_book.show()
            else:
                self.both_book = self.notebook_builder("both")
                self.note_box.add(self.both_book)
                self.both_book.show_all()

        if self.standard_radio.get_active():
            self.normal_book.hide()
            self.symbolic_book.hide()
            self.both_book.hide()
            self.standard_book.hide()
            if self.test_standard :
                self.standard_book.show()
            else:
                self.standard_book = self.notebook_builder("standard")
                self.note_box.add(self.standard_book)
                self.standard_book.show_all()

    def notebook_builder(self, name):

        chronoproc("Building a new notebook...")

        if name == "normal":
            building_list = self.normal_list
            self.test_normal = True

        elif name == "symbolic":
            building_list = self.symbolic_list
            self.test_symbolic = True

        elif name == "both":
            building_list = self.both_list
            self.test_both = True

        elif name == "standard":
            building_list = self.standard_list
            self.test_standard = True
        self.notebook = Gtk.Notebook()

        notebook = Gtk.Notebook()
        notebook.set_tab_pos(Gtk.PositionType.RIGHT)

        for i in building_list :
            if i.startswith("XXX"):
                tab_title = i[4:]
                tab_label = Gtk.Label(tab_title)
                new_listbox = Gtk.ListBox()
                scroll_box = Gtk.ScrolledWindow()
                scroll_box.set_properties(border_width=0)
                scroll_box.add(new_listbox)
                notebook.append_page(scroll_box, tab_label)

            else:
                row = MyRow(i)
                rowbox = Gtk.HBox()
                rowbox.set_homogeneous(False)
                row.add(rowbox)
                row_label = Gtk.Label(i)
                row_label.set_selectable(True)
                row_label.set_justify(Gtk.Justification.LEFT)
                row_icon = Gtk.Image.new_from_icon_name(i, Gtk.IconSize(5))
                rowbox.pack_start(row_label, False, False, 5)
                rowbox.pack_end(row_icon, False, False, 5)
                new_listbox.add(row)
                # color alternance:
                if row.get_index() % 2 == 0:
                    rowbox.override_background_color(Gtk.StateType.NORMAL, Gdk.RGBA(.3, .1, .4, .5))
        chronoproc("New Notebook Built")

        return notebook

    def info_clicked(self, widget):
        print("info clicked !")
        dialog = PopUpAbout(self)
        response = dialog.run()
        dialog.destroy()

class PopUpAbout(Gtk.AboutDialog):

    def __init__(self, parent):
        Gtk.Dialog.__init__(self, "About Iconopedia Gtk+", parent, Gtk.DialogFlags.MODAL)
        #self.set_size_request(300,400)
        self.set_comments("A handy tool for PyGObject devs !")
        self.set_logo(GdkPixbuf.Pixbuf.new_from_file("data/Peigne-plume-256-320.png"))
        self.set_copyright("Copyright 2017 Fabre Vincent <peigne-plume@laposte.net>")
        self.set_version("1.0")
        self.set_authors(["Vincent Fabre, <peigne-plume@laposte.net>"])
        self.set_license_type(Gtk.License.BSD)
        self.set_program_name("Iconopedia Gtk+")
        self.set_license(license_BSD)

        self.show_all()

window = MainWindow()
window.show_all()
window.connect("delete-event", Gtk.main_quit)

chronoproc("window displayed", "\n # Chrono #")

Gtk.main()
